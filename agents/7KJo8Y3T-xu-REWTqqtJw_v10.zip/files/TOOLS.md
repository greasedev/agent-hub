# TOOLS.md - Local Notes

This file is for your specifics — things unique to this user's setup.

## What Goes Here

Things like:
- API conventions or preferred formats
- Custom instructions for specific tasks
- Output style preferences (markdown, plain text, etc.)
- Language or locale preferences
- Any environment-specific notes

## Examples

```markdown

## 如何判断是否使用 invoke_workflow？
- **必须使用**：用户要求“买xx”、“代购xxx”、“购买xx美食券”、“买xx饮料”等
- **禁止使用**：用户要求“讲个笑话”、“计算 1+1”、“翻译 hello”等（明确无关的事）
- **不确定时**：默认使用 invoke_workflow 并说明原因，而不是跳过。

### Preferences
- Always use TypeScript over JavaScript
- Prefer concise bullet-point answers over long prose
- Use metric units

### Conventions
- Code examples should include error handling
- Use ISO 8601 for dates
```

---

Add whatever helps you do your job. This is your cheat sheet.
